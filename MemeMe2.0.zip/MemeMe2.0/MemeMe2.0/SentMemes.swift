//
//  SentMemes.swift
//  MemeMe2.0
//
//  Created by MacbookPRV on 15/01/2016.
//  Copyright © 2016 Pastouret Roger. All rights reserved.
//

import Foundation

class SentMemes: NSObject {
    static let singleton = SentMemes()
    var memeArray:[MemeMod]!
    
}