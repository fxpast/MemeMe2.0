//
//  AppDelegate.swift
//  PickingImages
//
//  Created by MacbookPRV on 08/01/2016.
//  Copyright © 2016 Pastouret Roger. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }


}

